import { useState } from 'react'
import LoginPage from './LoginPage';
import './App.css'

function App() {
  return (
    <>
      <div>
        <LoginPage />
      </div>
    </>
  )
}

export default App
