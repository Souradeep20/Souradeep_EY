import { useState } from 'react'
import './App.css'
import { OpenFixedDeposit } from "./OpenFixedDeposit";

function App() {

  return (
    <>
    <div className="App">
      <h1>Fixed Deposit Management</h1>
      <OpenFixedDeposit/>
      </div>   
    </>
  );
};

export default App
